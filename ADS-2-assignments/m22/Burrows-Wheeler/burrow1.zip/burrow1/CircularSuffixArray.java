// import edu.princeton.cs.algs4.Queue;
// import java.util.Arrays;
// import java.util.Comparator;
import java.util.Arrays;
import edu.princeton.cs.algs4.Queue;
import edu.princeton.cs.algs4.SuffixArrayX;
public class CircularSuffixArray {
    private final SuffixArrayX sa;

    public CircularSuffixArray(String s) {
        if (s == null) {
            throw new NullPointerException();
        }
        sa = new SuffixArrayX(s);
    }
    /**
     * Returns the length.
     *
     * @return     { description_of_the_return_value }
     */
    public int length() {
        return sa.length();
    }

    /**
     * returns index of ith sorted suffix
     *
     * @param i
     *            the index of the ith sorted suffix
     * @return
     */
    public int index(int i) {
        return sa.index(i);
    }
}
